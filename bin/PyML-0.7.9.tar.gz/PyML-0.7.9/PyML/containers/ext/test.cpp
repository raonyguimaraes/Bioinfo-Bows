
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <stdlib.h>

using namespace std;

int main(int argc, char** argv) {
  
  int c = -7400597625020045738;
  cout << c << endl;

}

  

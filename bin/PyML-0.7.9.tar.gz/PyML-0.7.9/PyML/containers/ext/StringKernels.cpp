SequenceData::double kmerDotProduct(string a, string b){	
  //1) find all substrings of length K and separate them
  for( int i = 0; i < a.size() - kmer_size; i++){
	string sub = a.substring(i, i+kamer);
		
  }
  //2) put them into a hashmap, so that all equal substrings fall to the same hash
  //3) go through each Kamer in the second string and hash it  (temp var)
  //4) add hashmap value at the given hash index
	
  return score;
  }
	


__version__ = '0.7.9'

from PyML.containers import *
from PyML.classifiers import *
from PyML.preproc import *
from PyML.demo import *
from PyML.feature_selection import *


SVM = __import__('PyML.classifiers.svm', fromlist=['']).SVM
KNN = __import__('PyML.classifiers.knn', fromlist=['']).KNN
RidgeRegression = __import__('PyML.classifiers.ridgeRegression', fromlist=['']).RidgeRegression
import modelSelection

